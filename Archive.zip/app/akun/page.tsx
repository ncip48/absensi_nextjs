import React from "react";

function Index() {
  return <div>Akun</div>;
}

export default Index;
